function analy_vsTraining_exp1(directory)

% written by Aisu on Feb/13th/2020 

%% ps and ss search (6 blocks + 6 blocks) for 7 days 

if ~exist('directory','var') || isempty(directory) 
	if ~ispc
		directory = '/Users/las/Desktop/AisuLi/trainingOnVsIOR/Data/Exp1';
	else
		directory = '/Users/las/Desktop/AisuLi/trainingOnVsIOR/Data/Exp1';
	end
end


try

cd(directory);

subId      = [1:13 17:21 23 24]; % valid subjects who completed 7-day-training
exSub      = [2 4 7 21]; % 
validSubId = setdiff(subId,exSub);
subNum	   = numel(subId);

allSubData = [];

for iSub = subId
	disp(iSub);
    disp('----');
	cSubData = [];

	cDir = fullfile(directory,num2str(iSub)); % each subject has a folder
	disp(cDir);

	cMatFiles = dir(fullfile(cDir,'*.mat')); % 2 tasks * 7 days = 14 files

	for iMat = 1:numel(cMatFiles)
		disp(cMatFiles(iMat).name);
		load(fullfile(cDir,cMatFiles(iMat).name));
		
		cMatData = [];
		cSubInfo = [];

		cDesignMatrix = [];
		for iBlock = 1:size(IT_training.designMatrix,3)
			cDesignMatrix = [cDesignMatrix;[repmat(iBlock,size(IT_training.designMatrix,1),1) IT_training.designMatrix(:,[2 3],iBlock)]];
		end	
		

		cMatData = [cDesignMatrix,...
					 IT_training.VRacc(:),...
					 IT_training.VRrts(:),...
					 IT_training.DPacc(:),...
					 IT_training.DPrts(:),...
					 IT_training.probeIdxs(:),...
					];

		cSubInfo = repmat([str2double(IT_training.num),...
		 			 str2double(IT_training.session),...
		 			 str2double(IT_training.age),...
		 			 strcmpi(IT_training.sex,'female'),...
		 			 strcmpi(IT_training.filename(end-1:end),'ps'),...  % 1 and 0 for ss and ps respectively
		 			 ],size(cMatData,1),1);

		 cSubData = [cSubData;[cSubInfo,cMatData]];

	end% iMat
%     subInfoInPaper(iSub,:) = cSubInfo(1,[1 3 4]);
	allSubData = [allSubData;cSubData];
end % for iSub


allSubDataInfo = {'num';'session';'age';'sex 1 fe;0 male'; 'tasktype: 0 ss 1 ps';...
				'block num'; 'VS target is present (2) or absent (1)'; ...
				'probe type (1 2 0 for on VS landmarker, not on landmarker and no probe [catch trial] respectively)';...
				'VSacc';'VSrts';'DPacc';'DPrts';'probeIdxs 1 for probe in vs target'};

dayNum = numel(unique(allSubData(:,2)));


allSubData(allSubData(:,7)==1,13) = 0;
allSubData(allSubData(:,8)~=1,13) = 0;

% subInfoInPaper(subInfoInPaper(:,1)==0,:)=[];


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% visual search %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%% calculate acc 
% [gm,gsd,gname,gcout] = grpstats(allSubData(:,9),{allSubData(:,1),allSubData(:,2),allSubData(:,5),allSubData(:,7)},{'mean','std','gname','numel'}); 
% gname                = cellfun(@str2double,gname); % sub * day * target precence * vs type 
% vsAcc                = [gname,gm];
% % vsAccForSpss         = reshape(ACC(:,4),numel(unique(gname(:,2))) * numel(unique(gname(:,3))),numel(unique(gname(:,1))))';


%%%% vs cutoff outliers
rowFilter = ~~allSubData(:,9);
[gm,gsd,gname,gcout] = grpstats(allSubData(rowFilter,10),{allSubData(rowFilter,1),allSubData(rowFilter,2),allSubData(rowFilter,5),allSubData(rowFilter,7)},{'mean','std','gname','numel'});
gname     = cellfun(@str2double,gname);
% [zscores] = shiftzs_BCL([gcout],0); 

for iRow = 1:size(gname,1)
	conFilter = allSubData(:,1) == gname(iRow,1) & allSubData(:,2) == gname(iRow,2) & allSubData(:,5) == gname(iRow,3) & allSubData(:,7) == gname(iRow,4);
	allSubData(conFilter,14) = gm(iRow) + 2.5*gsd(iRow);
	allSubData(conFilter,15) = 100;
end

%%% calculate RT
rowFilter = ~~allSubData(:,9) & allSubData(:,10)>allSubData(:,15) & allSubData(:,10)<=allSubData(:,14);

[gm,gsem,gname,gcout] = grpstats(allSubData(rowFilter,10),{allSubData(rowFilter,1),allSubData(rowFilter,2),allSubData(rowFilter,5),allSubData(rowFilter,7)},{'mean','sem','gname','numel'}); 

gname                 = cellfun(@str2double,gname); % sub * day * target precence * vs type 
vsRT                  = [gname,gm,gsem,gcout];
vsRTspss              = reshape(vsRT(:,5),dayNum*4,subNum)';

vsSpeedspss = zeros(subNum,dayNum,2);
for iSess = 1:dayNum
	vsSpeedspss(:,iSess,1)	= 8000./(vsRTspss(:,4*iSess-3) - vsRTspss(:,4*iSess-1));
	vsSpeedspss(:,iSess,2)	= 8000./(vsRTspss(:,4*iSess-2) - vsRTspss(:,4*iSess));
end




%%%%%%   fit a curve for everyone's vs speed
for iPre = 1:size(vsSpeedspss,3)
	for iSub = 1:size(vsSpeedspss,1)
		curve(iSub,:,iPre) = polyfit([1:dayNum],vsSpeedspss(iSub,:,iPre),1);
	end
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%--------- report search exclusions % in paper--------------/
vsTrialNum = 2*600*7;

%% overall error rates of search
rowFilter = ~~allSubData(:,9) & ismember(allSubData(:,1),validSubId); 
[gm,gsem,gname,corrgcout] = grpstats(allSubData(rowFilter,10),{allSubData(rowFilter,1)},{'mean','sem','gname','numel'});
100*(1-mean(corrgcout)/vsTrialNum)

% %% <100 or >2.5SD
rowFilter = ~~allSubData(:,9) & ismember(allSubData(:,1),validSubId) & allSubData(:,10)>allSubData(:,15) & allSubData(:,10)<=allSubData(:,14);
[gm,gsem,gname,gcout] = grpstats(allSubData(rowFilter,10),{allSubData(rowFilter,1)},{'mean','sem','gname','numel'});
100*(mean(corrgcout-gcout)/vsTrialNum)

%%%%--------  search exclusion -----------------------\



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  probe detection task %%%%%%%%%%%%%%%%%%%%%%%%%%%

% %%%%--------- report detection exclusions % in paper--------------/
pdTrialNum = vsTrialNum*0.8;

%%% false alarm %%%%
rowFilter  = allSubData(:,8)==0 & ismember(allSubData(:,1),validSubId);
[gm,gsem,gname,gcout] = grpstats(allSubData(rowFilter,11),{allSubData(rowFilter,1)},{'mean','sem','gname','numel'});
(1-mean(gm))*100

%%---- of totoal trials
rowFilter  = allSubData(:,8)==0 & ismember(allSubData(:,1),validSubId) & allSubData(:,11)==0;
[gm,gsem,gname,gcout] = grpstats(allSubData(rowFilter,12),{allSubData(rowFilter,1)},{'mean','sem','gname','numel'});
mean(gcout)./vsTrialNum*100

%%% miss probe %%%%
rowFilter  = allSubData(:,8)~=0 & ismember(allSubData(:,1),validSubId);
[gm,gsem,gname,gcout] = grpstats(allSubData(rowFilter,11),{allSubData(rowFilter,1)},{'mean','sem','gname','numel'});
(1-mean(gm))*100

%%---- of totoal trials
rowFilter  = allSubData(:,8)~=0 & ismember(allSubData(:,1),validSubId) & allSubData(:,11)==0;
[gm,gsem,gname,gcout] = grpstats(allSubData(rowFilter,12),{allSubData(rowFilter,1)},{'mean','sem','gname','numel'});
mean(gcout)./vsTrialNum*100


%% preceded by incorrect search response
rowFilter = ~~allSubData(:,11) &  ismember(allSubData(:,1),validSubId);
[gm,gsem,gname,corrgcout1] = grpstats(allSubData(rowFilter,12),{allSubData(rowFilter,1)},{'mean','sem','gname','numel'});

rowFilter = ~~allSubData(:,11) & ismember(allSubData(:,1),validSubId) & ~~allSubData(:,9);
[gm,gsem,gname,corrgcout2] = grpstats(allSubData(rowFilter,12),{allSubData(rowFilter,1)},{'mean','sem','gname','numel'});

mean(corrgcout1-corrgcout2)/vsTrialNum*100


%% probe appearing at the search target location 

rowFilter = ~~allSubData(:,9) & ~~allSubData(:,11) & ismember(allSubData(:,1),validSubId) & allSubData(:,7)==2 & allSubData(:,8)==1 & allSubData(:,13)==1;
[gm,gsem,gname,corrgcout]  = grpstats(allSubData(rowFilter,12),{allSubData(rowFilter,1)},{'mean','sem','gname','numel'});
100*mean(corrgcout)./vsTrialNum


%% PD cutoff outliers
rowFilter = ~~allSubData(:,9) & ~~allSubData(:,11) & allSubData(:,13)~=1;
[gm,gsd,gname,gcout] = grpstats(allSubData(rowFilter,12),{allSubData(rowFilter,1),allSubData(rowFilter,2),allSubData(rowFilter,5),allSubData(rowFilter,7),allSubData(rowFilter,8)},{'mean','std','gname','numel'});
gname     = cellfun(@str2double,gname);
% [zscores] = shiftzs_BCL([gcout],0); 

for iRow = 1:size(gname,1)
	conFilter = allSubData(:,1) == gname(iRow,1) & allSubData(:,2) == gname(iRow,2) & allSubData(:,5) == gname(iRow,3) & allSubData(:,7) == gname(iRow,4) & allSubData(:,8) == gname(iRow,5);
	allSubData(conFilter,16) = gm(iRow) + 2.5*gsd(iRow);
	allSubData(conFilter,17) = 100;
end



rowFilter = ~~allSubData(:,9) & ~~allSubData(:,11) & ismember(allSubData(:,1),validSubId) & allSubData(:,8)>0 & allSubData(:,13)~=1;
[gm,gsem,gname,gcout1] = grpstats(allSubData(rowFilter,12),{allSubData(rowFilter,1)},{'mean','sem','gname','numel'});


%% <100 or >2.5SD
rowFilter = ~~allSubData(:,9) & ~~allSubData(:,11) & ismember(allSubData(:,1),validSubId) & allSubData(:,8)>0 & allSubData(:,13)~=1  & allSubData(:,12)>allSubData(:,17) & allSubData(:,12)<=allSubData(:,16);
[gm,gsem,gname,gcout2] = grpstats(allSubData(rowFilter,12),{allSubData(rowFilter,1)},{'mean','sem','gname','numel'});
(mean(gcout1-gcout2)/vsTrialNum)*100





%%% calculate RT
rowFilter = ~~allSubData(:,9) & ~~allSubData(:,11) & allSubData(:,12)>allSubData(:,17) & allSubData(:,12)<=allSubData(:,16) & allSubData(:,8)>0 & allSubData(:,13)~=1;

[gm,gsem,gname,gcout] = grpstats(allSubData(rowFilter,12),{allSubData(rowFilter,1),allSubData(rowFilter,2),allSubData(rowFilter,5),allSubData(rowFilter,7),allSubData(rowFilter,8)},{'mean','sem','gname','numel'}); 

gname                 = cellfun(@str2double,gname); % sub * day * target precence * vs type * detec
pdRT                  = [gname,gm,gsem,gcout];
pdRTspss              = reshape(pdRT(:,6),dayNum*8,subNum)';

%%%% calculate IOR 
for iSess = 1:dayNum
	IORspss(:,iSess,1)	= pdRTspss(:,8*iSess-7) - pdRTspss(:,8*iSess-6) - pdRTspss(:,8*iSess-3) + pdRTspss(:,8*iSess-2);
	IORspss(:,iSess,2)	= pdRTspss(:,8*iSess-5) - pdRTspss(:,8*iSess-4) - pdRTspss(:,8*iSess-1) + pdRTspss(:,8*iSess);
end



for iPre = 1:size(IORspss,3)
	for iSub = 1:size(IORspss,1)
		curveIOR(iSub,:,iPre) = polyfit([1:dayNum],IORspss(iSub,:,iPre),1);
	end
end







catch analy_vsTraining_exp1_error
        cd ..
		save analy_vsTraining_exp1_debug;
		rethrow(analy_vsTraining_exp1_error);		
end


end % function